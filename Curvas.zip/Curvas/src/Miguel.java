import java.awt.Color;
import static java.awt.Color.red;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;

/**
 *
 * @author retom
 */
public class Miguel extends JFrame {

    int[][] cuboPuntos = {
            {100, 100, 100},
            {200, 100, 100},
            {200, 200, 100},
            {100, 200, 100},
            {100, 200, 200},
            {200, 200, 200},
            {200, 100, 200},
            {100, 100, 200}
    };
    int[][] cubo;
    int[] p;

    private BufferedImage buffer;
    private Graphics graPixel;

    public Miguel() {
        setTitle("Cubo");
        setSize(550, 600);
        setLayout(null);
        buffer = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);
        graPixel = (Graphics2D) buffer.createGraphics();
    }

    public static void main(String[] args) {
        Miguel c = new Miguel();
        c.show();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        p = new int[]{50, 20, 30};
        dibujarCubo(Color.BLUE, 0, 0);
        p = new int[]{30, 50, 120};
        dibujarCubo(Color.RED, 0, 300);
        p = new int[]{60, 10, 100};
        dibujarCubo(Color.GREEN, 330, 0);
    }

    public void dibujarCubo(Color c, int movx, int movy) {
        int xp = p[0];
        int yp = p[1];
        int zp = p[2];
        int x = 0, y = 0;

        cubo = new int[8][2];

        for (int i = 0; i < 8; i++) {
            x = Math.abs(cuboPuntos[i][0] + xp * (-cuboPuntos[i][2] / zp)+movx);
            y = Math.abs(cuboPuntos[i][1] + yp * (-cuboPuntos[i][2] / zp)+movy);
            //putPixel(x, y, Color.BLUE);
            // System.out.println("x " + x + " y " + y);
            cubo[i][0] = x;
            cubo[i][1] = y;

        }

        for (int i = 0; i < 8; i++) {
            switch (i) {
                case 3 ->
                        lineaDDA(cubo[i][0], cubo[i][1], cubo[0][0], cubo[0][1], c);
                case 7 ->
                        lineaDDA(cubo[i][0], cubo[i][1], cubo[4][0], cubo[4][1], c);
                default ->
                        lineaDDA(cubo[i][0], cubo[i][1], cubo[i + 1][0], cubo[i + 1][1],c);
            }
            if (i < 4) {
                lineaDDA(cubo[i][0], cubo[i][1], cubo[7 - i][0], cubo[7 - i][1], c);
            }

        }

    }

    public void lineaDDA(double x0, double y0, double x1, double y1, Color c) {
        double difx = 0, dify = 0, steps = 0;
        double xinc = 0, yinc = 0;
        double xf = 0, yf = 0;
        difx = x1 - x0;
        dify = y1 - y0;

        if (Math.abs(difx) > Math.abs(dify)) {
            steps = Math.abs(difx);
        } else {
            steps = Math.abs(dify);
        }

        try {
            xinc = difx / steps;
            yinc = (float) dify / steps;
        } catch (Exception e) {
            //h
        };

        xf = x0;
        yf = y0;
        putPixel((int) xf, (int) yf, c);
        for (int i = 1; i <= steps; i++) {
            xf = (xf + xinc);
            yf = (yf + yinc);

            putPixel((int) xf, (int) yf, c);
        }

    }

    public void putPixel(int x, int y, Color c) {
        buffer.setRGB(0, 0, c.getRGB());
        this.getGraphics().drawImage(buffer, x, y, this);
    }
}
